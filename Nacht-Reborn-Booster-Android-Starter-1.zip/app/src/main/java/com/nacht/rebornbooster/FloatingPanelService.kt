package com.nacht.rebornbooster

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: TextView? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bubbleParams = WindowManager.LayoutParams(
            58, 58, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 220 }
        bubble = TextView(this).apply {
            text = "N"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = shape(Color.rgb(28, 30, 35), 29f)
            setOnTouchListener(DragTouchListener())
        }
        wm.addView(bubble, bubbleParams)
    }

    private fun togglePanel() {
        if (panel != null) {
            try { wm.removeView(panel) } catch (_: Exception) {}
            panel = null
            return
        }
        val params = WindowManager.LayoutParams(
            240, 170, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = bubbleParams.x; y = bubbleParams.y + 68 }
        panel = TextView(this).apply {
            text = "NACHT • QUICK PANEL\n\nOverlay permission: ON\nAndroid controls app access.\nTap bubble to close."
            textSize = 14f; setTextColor(Color.WHITE); setPadding(18, 18, 18, 18)
            background = shape(Color.rgb(20, 22, 26), 20f)
        }
        wm.addView(panel, params)
    }

    private fun shape(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius; setStroke(2, Color.rgb(180, 184, 192))
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var downX = 0; private var downY = 0
        private var startX = 0; private var startY = 0; private var dragged = false

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX.toInt(); downY = event.rawY.toInt()
                    startX = bubbleParams.x; startY = bubbleParams.y; dragged = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX.toInt() - downX; val dy = event.rawY.toInt() - downY
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) dragged = true
                    bubbleParams.x = startX + dx; bubbleParams.y = startY + dy
                    try { wm.updateViewLayout(bubble, bubbleParams) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> { if (!dragged) togglePanel(); return true }
            }
            return false
        }
    }

    override fun onDestroy() {
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        bubble = null; panel = null
        super.onDestroy()
    }
}
