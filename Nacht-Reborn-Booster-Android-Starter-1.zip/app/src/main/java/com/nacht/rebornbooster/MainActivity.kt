package com.nacht.rebornbooster

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

private val Ink = Color(0xFF08090B)
private val Panel = Color(0xFF17191D)
private val Silver = Color(0xFFD7D9DE)
private val Muted = Color(0xFF9DA2AC)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.US
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Ink, surface = Panel, primary = Silver,
                onBackground = Silver, onSurface = Silver
            )) {
                var page by remember { mutableStateOf("Home") }
                var message by remember { mutableStateOf("Ready. No performance scan has been run.") }
                Scaffold(containerColor = Ink, bottomBar = {
                    NavigationBar(containerColor = Panel) {
                        listOf("Home", "Games", "Tools", "Guide").forEach { item ->
                            NavigationBarItem(
                                selected = page == item, onClick = { page = item },
                                icon = { Icon(when (item) {
                                    "Games" -> Icons.Default.SportsEsports
                                    "Tools" -> Icons.Default.Tune
                                    "Guide" -> Icons.Default.School
                                    else -> Icons.Default.Dashboard
                                }, contentDescription = item) },
                                label = { Text(item) }
                            )
                        }
                    }
                }) { padding ->
                    LazyColumn(
                        Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        contentPadding = PaddingValues(top = 24.dp, bottom = 28.dp)
                    ) {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("NACHT", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                                    Text("REBORN BOOSTER • EARLY ACCESS", color = Muted, style = MaterialTheme.typography.labelSmall)
                                }
                                Surface(shape = RoundedCornerShape(14.dp), color = Panel) {
                                    Icon(Icons.Default.DarkMode, null, Modifier.padding(14.dp), tint = Silver)
                                }
                            }
                        }
                        item {
                            Surface(color = Panel, shape = RoundedCornerShape(24.dp)) {
                                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("CONTROL CENTER", color = Muted, style = MaterialTheme.typography.labelMedium)
                                    Text(when (page) {
                                        "Games" -> "Your games, one place."
                                        "Tools" -> "Useful Android tools."
                                        "Guide" -> "Learn what each feature does."
                                        else -> "Focus. Control. Clarity."
                                    }, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                    Text("A clean dashboard for launching apps and managing the floating panel. Android limits what a booster can change behind the scenes.", color = Muted)
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Button(onClick = {
                                            if (!Settings.canDrawOverlays(this@MainActivity)) {
                                                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                                                message = "Allow display over other apps, then return here."
                                            } else {
                                                startService(Intent(this@MainActivity, FloatingPanelService::class.java))
                                                message = "Floating panel started."
                                            }
                                        }, modifier = Modifier.weight(1f)) {
                                            Icon(Icons.Default.Widgets, null)
                                            Spacer(Modifier.width(6.dp))
                                            Text("Floating panel")
                                        }
                                        OutlinedButton(onClick = {
                                            stopService(Intent(this@MainActivity, FloatingPanelService::class.java))
                                            message = "Panel stop requested."
                                        }) { Icon(Icons.Default.Close, null) }
                                    }
                                }
                            }
                        }
                        item { StatusCard("STATUS", message, Icons.Default.Info) }
                        item { StatusCard("FREE ACCESS", "Core dashboard and app launching. Premium and account services are not connected in this prototype.", Icons.Default.LockOpen) }
                        item {
                            Surface(color = Panel, shape = RoundedCornerShape(20.dp)) {
                                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("QUICK ACTIONS", fontWeight = FontWeight.Bold)
                                    OutlinedButton(onClick = {
                                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                                    }, modifier = Modifier.fillMaxWidth()) {
                                        Icon(Icons.Default.Security, null); Spacer(Modifier.width(8.dp)); Text("App permissions")
                                    }
                                    OutlinedButton(onClick = {
                                        tts?.speak("Welcome to Nacht Reborn Booster. Use the floating panel button to enable the optional overlay.", TextToSpeech.QUEUE_FLUSH, null, "welcome")
                                        message = "Spoken walkthrough requested."
                                    }, modifier = Modifier.fillMaxWidth()) {
                                        Icon(Icons.Default.RecordVoiceOver, null); Spacer(Modifier.width(8.dp)); Text("Hear quick guide")
                                    }
                                }
                            }
                        }
                        item {
                            Text("Prototype build • No fake FPS claims • Login, cloud sync, ZIP extraction and diagnostics are not implemented yet.", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}

@Composable
private fun StatusCard(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = Silver, modifier = Modifier.padding(end = 12.dp, top = 2.dp))
            Column {
                Text(title, style = MaterialTheme.typography.labelMedium, color = Muted)
                Spacer(Modifier.height(4.dp))
                Text(detail, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
